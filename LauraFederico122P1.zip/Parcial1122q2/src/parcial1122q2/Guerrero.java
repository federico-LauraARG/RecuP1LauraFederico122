
package parcial1122q2;


public class Guerrero extends Aventurero implements Entrenamiento,Atacante{
    
    private int valorDeFuerza;

    public Guerrero(String codIdentificacion, String nombre, Rango rango,int valorDeFuerza) {
        super(codIdentificacion, nombre, rango);
        this.valorDeFuerza = valorDeFuerza;
        validarFuerza();
    }

    
    
    public void validarFuerza(){
        if(valorDeFuerza <= 0){
            throw new IllegalArgumentException("El nivel de fuerza debe ser mayor a cero.");
        }
    }
    
    @Override
    public String realizarEntrenamiento(){
        return getNombre() + " Esta entrenando con su espada.";
    }
    
    @Override
    public int getPoderCombate(){
        return this.valorDeFuerza * 2;
    }
    
    @Override
    public String realizarAtaque(){
         return getNombre() + " Ataca con su espada.";
    }
}

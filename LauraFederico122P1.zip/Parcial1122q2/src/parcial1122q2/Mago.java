
package parcial1122q2;


public class Mago extends Aventurero implements Atacante{
    
    private int puntosMana;

    public Mago(String codIdentificacion, String nombre, Rango rango,int puntosMana) {
        super(codIdentificacion, nombre, rango);
        this.puntosMana = puntosMana;
        validarMana();
    }

    
    
     public void validarMana(){
        if(puntosMana <= 0){
            throw new IllegalArgumentException("El nivel de mana debe ser mayor a cero.");
        }
    }
     
     @Override
     public String realizarAtaque(){
         return getNombre() + " Lanza un hechizo.";
     }
     
     @Override
     public int getPoderCombate(){
         return this.puntosMana + 10;
     }
}

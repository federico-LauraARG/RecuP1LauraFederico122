
package parcial1122q2;

import java.util.Objects;


public abstract class Aventurero{
    
    private String codIdentificacion;
    private String nombre;
    private Rango rango;

    
    /**
     * cree el constructor con los atributos declarados.
     * @param codIdentificacion de tipo string.
     * @param nombre de tipo string.
     * @param rango de tipo Rango.
     */
    public Aventurero(String codIdentificacion, String nombre, Rango rango) {
        this.codIdentificacion = codIdentificacion;
        this.nombre = nombre;
        this.rango = rango;
        validarNull();
    }

    
    /**
     * Obtiene el código de identificación del aventurero.
     * @return el código de identificación.
     */
    public String getCodIdentificacion() {
        return codIdentificacion;
    }

    
    /**
     * Obtiene el nombre del aventurero.
     * @return el nombre del aventurero.
     */
    public String getNombre() {
        return nombre;
    }

    
    /**
     * Obtiene el rango actual del aventurero.
     * @return el rango (BRONCE, PLATA, ORO)
     */
    public Rango getRango() {
        return rango;
    }
    
    
    /**
     *Valida que los atributos obligatorios del aventurero no sean nulos ni estén en blanco.
     * @throws IllegalArgumentException si el código, el nombre o el rango no cumplen con las condiciones.
     */
    public void validarNull(){
        if(codIdentificacion == null || codIdentificacion.isBlank()){
            throw new IllegalArgumentException("El codigo de identificacion no puede ser nulo ni estar en blanco.");
        }
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre no puede ser nulo ni estar en blanco.");
        }
        if(rango == null){
            throw new IllegalArgumentException("El rango no puede ser nulo.");
        }
    }


    
    /**
     * Calcula el código hash basado en la identificación y el nombre del aventurero.
     * @return el valor entero de hash.
     */
    @Override
    public int hashCode() {
        return Objects.hash(this.codIdentificacion, this.nombre);
    }

    
    /**
     * Compara si este aventurero es igual a otro objeto basándose en su nombre y código de identificación.
     * @param obj el objeto a comparar.
     * @return true si ambos aventureros coinciden en nombre y código, false en caso contrario.
     */
    @Override
    public boolean equals(Object obj){
        if(obj == null){
            return false;
        }
        if(obj == this){
            return true;
        }
        if(obj instanceof Aventurero otro){
            return(nombre.equals(otro.nombre) && codIdentificacion.equals(otro.codIdentificacion));
        }
        return false;
    }
    

    /**
     * Método abstracto para calcular y obtener el poder de combate del aventurero.
     * @return el valor numérico del poder de combate.
     */
    public abstract int getPoderCombate();

    
    /**
     * Devuelve una representación en cadena de texto con los datos principales del aventurero.
     * @return una cadena con el código, nombre, rango y poder de combate.
     */
    @Override
    public String toString() {
        return "Aventurero[" + "codIdentificacion= " + codIdentificacion + ", nombre= " + nombre + ", rango= " + rango + " poder de combate= " + getPoderCombate() + ']';
    }
    
    
}

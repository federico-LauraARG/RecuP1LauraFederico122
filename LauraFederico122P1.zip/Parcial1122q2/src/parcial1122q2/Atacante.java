
package parcial1122q2;


public interface Atacante {
    
    public String realizarAtaque();
}

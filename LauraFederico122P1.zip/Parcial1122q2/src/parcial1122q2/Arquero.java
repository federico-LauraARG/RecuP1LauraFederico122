
package parcial1122q2;


public class Arquero extends Aventurero implements Entrenamiento,Atacante{
    
    private int valorPrecision;

    public Arquero(String codIdentificacion, String nombre, Rango rango,int valorPrecision) {
        super(codIdentificacion, nombre, rango);
        this.valorPrecision = valorPrecision;
        validarPrecision();
    }
    
    
     public void validarPrecision(){
        if(valorPrecision <= 0){
            throw new IllegalArgumentException("El nivel de precision debe ser mayor a cero.");
        }
    }
     
     @Override
     public String realizarEntrenamiento(){
          return getNombre() + " Esta entrenando con su arco.";
     }
     
     @Override
     public String realizarAtaque(){
         return getNombre() + " Dispara una flecha.";
     }
     
     @Override
     public int getPoderCombate(){
         return this.valorPrecision * 3;
     }
}
